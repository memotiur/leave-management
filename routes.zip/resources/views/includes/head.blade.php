<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">
<title>Admin -@yield('title')</title>


<link rel="stylesheet" href="/app/css/bootstrap.css">

<link rel="stylesheet" href="/plugins/fontawesome/css/font-awesome.min.css">
<link rel="stylesheet" href="/plugins/animo/animate%2banimo.css">
<link rel="stylesheet" href="/plugins/csspinner/csspinner.min.css">

<link rel="stylesheet" href="/app/css/app.css">

<script src="/plugins/modernizr/modernizr.js" type="application/javascript"></script>

<script src="/plugins/fastclick/fastclick.js" type="application/javascript"></script>
<link rel="stylesheet" href="/plugins/chosen/chosen.min.css">
<link rel="stylesheet" href="/plugins/slider/css/slider.css">
<link rel="stylesheet" href="/app/css/app.css">
