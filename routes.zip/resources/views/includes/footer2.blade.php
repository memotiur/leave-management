
<script src="/plugins/bootstrap/js/bootstrap.min.js"></script>

<script src="/plugins/chosen/chosen.jquery.min.js"></script>
<script src="/plugins/slider/js/bootstrap-slider.js"></script>
<script src="/plugins/filestyle/bootstrap-filestyle.min.js"></script>

<script src="/plugins/animo/animo.min.js"></script>

<script src="/plugins/sparklines/jquery.sparkline.min.js"></script>

<script src="/plugins/slimscroll/jquery.slimscroll.min.js"></script>


<script src="/plugins/flot/jquery.flot.min.js"></script>
<script src="/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="/plugins/flot/jquery.flot.resize.min.js"></script>
<script src="/plugins/flot/jquery.flot.pie.min.js"></script>
<script src="/plugins/flot/jquery.flot.time.min.js"></script>
<script src="/plugins/flot/jquery.flot.categories.min.js"></script>
<!--[if lt IE 8]>
<script src="/js/excanvas.min.js"></script><![endif]-->


<script src="/plugins/datatable/media/js/jquery.dataTables.min.js"></script>
<script src="/plugins/datatable/extensions/datatable-bootstrap/js/dataTables.bootstrap.js"></script>
<script src="/plugins/datatable/extensions/datatable-bootstrap/js/dataTables.bootstrapPagination.js"></script>
<script src="/plugins/datatable/extensions/ColVis/js/dataTables.colVis.min.js"></script>

<script src="/app/js/app.js"></script>
